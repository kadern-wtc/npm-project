function doSomething(){
    console.log("doing something");
}

function anotherFunction(){
    console.log("foo");
}

export {doSomething, anotherFunction}